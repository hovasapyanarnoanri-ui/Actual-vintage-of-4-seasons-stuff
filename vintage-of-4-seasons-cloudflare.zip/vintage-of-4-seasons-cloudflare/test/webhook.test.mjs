// Run with:  node test/webhook.test.mjs
// Uses a pretend Stripe and a pretend email service. Nothing is sent. Every line should say PASS.
import fs from 'node:fs'; import os from 'node:os'; import path from 'node:path'; import crypto from 'node:crypto';
import { fileURLToPath, pathToFileURL } from 'node:url';
const here = path.dirname(fileURLToPath(import.meta.url));
const tmp = path.join(os.tmpdir(), 'webhook-under-test.mjs');
fs.copyFileSync(path.join(here, '../functions/api/stripe-webhook.js'), tmp);
const { onRequest } = await import(pathToFileURL(tmp).href);

const env = { STRIPE_SECRET_KEY: 'sk_test_x', STRIPE_WEBHOOK_SECRET: 'whsec_test', RESEND_API_KEY: 're_test', ORDER_EMAIL: 'shop@gmail.com' };
let calls = [], stripeOk = true, emailOk = true;
const session = {
  id: 'cs_test_1', payment_status: 'paid', amount_total: 20250, payment_intent: 'pi_123',
  customer_details: { name: 'Pat Smith', email: 'pat@mail.com', phone: '+13105551212' },
  collected_information: { shipping_details: { name: 'Pat Smith', address: { line1: '1 Main St', city: 'Van Nuys', state: 'CA', postal_code: '91401', country: 'US' } } },
  metadata: { address: '1 Main St' },
  line_items: { data: [{ quantity: 2, description: 'Handcrafted Winter Angel — Red', amount_total: 17000 }, { quantity: 1, description: 'Shipping (estimate)', amount_total: 750 }] },
};
globalThis.fetch = async (url, init = {}) => {
  calls.push({ url: String(url), init });
  if (String(url).startsWith('https://api.stripe.com/')) return stripeOk ? new Response(JSON.stringify(session), { status: 200 }) : new Response('{}', { status: 500 });
  if (String(url).startsWith('https://api.resend.com/')) return emailOk ? new Response('{"id":"x"}', { status: 200 }) : new Response('{}', { status: 500 });
  throw new Error('unexpected call ' + url);
};
const sign = (body, t = Math.floor(Date.now() / 1000), secret = env.STRIPE_WEBHOOK_SECRET) =>
  't=' + t + ',v1=' + crypto.createHmac('sha256', secret).update(t + '.' + body).digest('hex');
const send = (body, header, e = env, method = 'POST') =>
  onRequest({ request: new Request('https://shop.test/api/stripe-webhook', { method, body: method === 'POST' ? body : undefined, headers: header ? { 'Stripe-Signature': header } : {} }), env: e });
const event = (type = 'checkout.session.completed', obj = { id: 'cs_test_1', payment_status: 'paid' }) => JSON.stringify({ type, data: { object: obj } });
const emails = () => calls.filter((c) => c.url.startsWith('https://api.resend.com/'));
let failed = 0;
const check = (name, ok, extra = '') => { console.log((ok ? 'PASS ' : 'FAIL ') + name + (extra ? '  ' + extra : '')); if (!ok) failed++; };

let body = event(); calls = [];
let r = await send(body, sign(body));
check('a real paid order is accepted', r.status === 200);
const mail = JSON.parse(emails()[0].init.body);
check('email goes to the shop address', JSON.stringify(mail.to) === '["shop@gmail.com"]');
check('email has the items, total, address, phone', ['2 x Handcrafted Winter Angel', '$202.50', '1 Main St', 'Van Nuys', '+13105551212', 'pat@mail.com'].every((s) => mail.text.includes(s)), mail.subject);
check('email is plain text only (no HTML)', mail.html === undefined);
check('Stripe lookup uses the secret key', calls[0].init.headers.Authorization === 'Bearer sk_test_x');
check('email service call uses the Resend key', emails()[0].init.headers.Authorization === 'Bearer re_test');

calls = []; r = await send(body, sign(body, undefined, 'whsec_WRONG')); check('wrong secret -> 400, no email', r.status === 400 && calls.length === 0);
calls = []; r = await send(body, sign(body, Math.floor(Date.now() / 1000) - 3600)); check('old (replayed) call -> 400', r.status === 400 && calls.length === 0);
calls = []; r = await send(body, undefined); check('no signature -> 400', r.status === 400 && calls.length === 0);
calls = []; r = await send(body + ' ', sign(body)); check('body changed after signing -> 400', r.status === 400 && calls.length === 0);
calls = []; r = await send(body, 'garbage'); check('garbage signature header -> 400', r.status === 400 && calls.length === 0);
const t = Math.floor(Date.now() / 1000), good = sign(body, t);
calls = []; r = await send(body, good.replace('v1=', 'v1=bad1,v1=').replace(',v1=bad1,v1=', ',v1=bad1,v1=')); check('several signatures, one valid -> accepted', r.status === 200);
body = event('charge.refunded'); calls = []; r = await send(body, sign(body)); check('other event types are ignored (200, no email)', r.status === 200 && emails().length === 0);
body = event('checkout.session.completed', { id: 'cs_x', payment_status: 'unpaid' }); calls = []; r = await send(body, sign(body)); check('unpaid session -> no email', r.status === 200 && emails().length === 0);
body = event('checkout.session.completed', {}); calls = []; r = await send(body, sign(body)); check('session without id -> 400', r.status === 400);
body = event(); stripeOk = false; calls = []; r = await send(body, sign(body)); check('cannot read order from Stripe -> 500 (Stripe retries)', r.status === 500 && emails().length === 0); stripeOk = true;
emailOk = false; calls = []; r = await send(body, sign(body)); check('email service fails -> 500 (Stripe retries)', r.status === 500); emailOk = true;
for (const name of Object.keys(env)) { const e = { ...env }; delete e[name]; r = await send(body, sign(body), e); check('missing ' + name + ' -> 500', r.status === 500); }
r = await send(body, sign(body), env, 'GET'); check('GET -> 405', r.status === 405);
console.log(failed ? '\n' + failed + ' check(s) FAILED' : '\nAll checks passed');
process.exit(failed ? 1 : 0);

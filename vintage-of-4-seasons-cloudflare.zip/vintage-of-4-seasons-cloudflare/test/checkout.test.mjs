// Run with:  node test/checkout.test.mjs
// Uses a pretend Stripe, so nothing is charged. Every line should say PASS.
import fs from 'node:fs'; import os from 'node:os'; import path from 'node:path'; import { fileURLToPath, pathToFileURL } from 'node:url';
const here = path.dirname(fileURLToPath(import.meta.url));
const tmp = path.join(os.tmpdir(), 'checkout-under-test.mjs');
fs.copyFileSync(path.join(here, '../functions/api/checkout.js'), tmp);
const { onRequest } = await import(pathToFileURL(tmp).href);

let sent = null, mode = 'ok';
globalThis.fetch = async (url, init) => {
  sent = { url, init, form: new URLSearchParams(init.body) };
  if (mode === 'down') throw new Error('network down');
  if (mode === 'reject') return new Response(JSON.stringify({ error: { message: 'bad' } }), { status: 400 });
  return new Response(JSON.stringify({ url: 'https://checkout.stripe.com/c/pay/TEST' }), { status: 200 });
};
const env = { STRIPE_SECRET_KEY: 'sk_test_x', SITE_URL: 'https://example-shop.com' };
const get = (qs, e = env) => onRequest({ request: new Request('https://shop.test/api/checkout?' + new URLSearchParams(qs)), env: e });
const cart = (rows) => JSON.stringify(rows);
const amounts = () => [...sent.form.entries()].filter(([k]) => k.endsWith('[unit_amount]')).map(([, v]) => Number(v));
let failed = 0;
const check = (name, ok, extra = '') => { console.log((ok ? 'PASS ' : 'FAIL ') + name + (extra ? '  ' + extra : '')); if (!ok) failed++; };

let r = await get({ cart: cart([['Handcrafted Winter Angel', 'Red', 2], ['Large Medallion Ornament', 'Cream', 1]]), zip: '90210', email: 'a@b.co' });
check('normal cart redirects to Stripe', r.status === 303 && r.headers.get('Location').startsWith('https://checkout.stripe.com/'));
check('prices and shipping are right (8499, 13499, 750)', JSON.stringify(amounts()) === '[8499,13499,750]', JSON.stringify(amounts()));
r = await get({ cart: cart([['High Heel Ornament', 'Royal Blue', 1]]), zip: '90210' });
check('High Heel pair is 44.99 (4499)', amounts()[0] === 4499, JSON.stringify(amounts()));
r = await get({ cart: cart([['Handcrafted Winter Angel', 'Red', 2], ['Large Medallion Ornament', 'Cream', 1]]), zip: '90210', email: 'a@b.co' });
check('request goes to Stripe with the secret key', sent.url === 'https://api.stripe.com/v1/checkout/sessions' && sent.init.headers.Authorization === 'Bearer sk_test_x');
check('shipping address + phone collected, US only', sent.form.get('shipping_address_collection[allowed_countries][0]') === 'US' && sent.form.get('phone_number_collection[enabled]') === 'true');
check('success/cancel links use SITE_URL', sent.form.get('success_url') === 'https://example-shop.com?paid=1' && sent.form.get('cancel_url') === 'https://example-shop.com');
r = await get({ cart: cart([['Handcrafted Winter Angel', 'Red', 1, 0.01]]), zip: '10001' });
check('a price sent by the browser is ignored', amounts()[0] === 8499, String(amounts()[0]));
for (const [label, c] of [['unknown product', [['Fake Item', 'Red', 1]]], ['negative quantity', [['Angel Ornament', 'Red', -5]]], ['fractional quantity', [['Angel Ornament', 'Red', 1.5]]], ['quantity over 50', [['Angel Ornament', 'Red', 51]]], ['unknown size', [['Ornament Gift Box', 'Red · Giant', 1]]], ['size = constructor', [['Ornament Gift Box', 'Red · constructor', 1]]], ['name = __proto__', [['__proto__', 'Red · toString', 1]]], ['name = constructor', [['constructor', 'Red', 1]]], ['name is a number', [[5, 'Red', 1]]]]) {
  r = await get({ cart: cart(c) }); check(label + ' -> 400', r.status === 400);
}
r = await get({ cart: 'not json' }); check('bad JSON -> 400', r.status === 400);
r = await get({}); check('no cart -> 400', r.status === 400);
r = await onRequest({ request: new Request('https://shop.test/api/checkout', { method: 'POST', body: '{bad json' }), env }); check('broken POST body -> 400', r.status === 400);
r = await onRequest({ request: new Request('https://shop.test/api/checkout', { method: 'POST', body: JSON.stringify({ cart: [['Angel Ornament', 'Red', 1]] }) }), env });
check('POST returns the Stripe link as JSON', r.status === 200 && (await r.json()).url.includes('checkout.stripe.com'));
r = await onRequest({ request: new Request('https://shop.test/api/checkout', { method: 'DELETE' }), env }); check('other methods -> 405', r.status === 405);
r = await get({ cart: cart([['Angel Ornament', 'Red', 1]]) }, { SITE_URL: 'https://x.com' }); check('missing Stripe key -> 500', r.status === 500);
r = await get({ cart: cart([['Angel Ornament', 'Red', 1]]) }, { STRIPE_SECRET_KEY: 'sk_test_x' }); check('missing SITE_URL -> 500', r.status === 500);
r = await get({ cart: cart([['Angel Ornament', 'Red', 1]]) }, { STRIPE_SECRET_KEY: 'sk_test_x', SITE_URL: 'example.com' }); check('SITE_URL without https -> 500', r.status === 500);
mode = 'reject'; r = await get({ cart: cart([['Angel Ornament', 'Red', 1]]) }); check('Stripe says no -> friendly 500', r.status === 500);
mode = 'down'; r = await get({ cart: cart([['Angel Ornament', 'Red', 1]]) }); check('Stripe unreachable -> friendly 500', r.status === 500);
mode = 'ok';
await get({ cart: cart([['Angel Ornament', 'Red', 1], ['Guitar Ornament', 'Red', 1]]), zip: '90001' });
check('shipping for 2 lines, ZIP 9xxxx = 750 cents', amounts().at(-1) === 750, String(amounts().at(-1)));

// ---- Gift Box ----
const box = (items, extra = []) => cart([['Ornament Gift Box', 'Red', 1, items], ...extra]);
const nameOf = (i = 0) => sent.form.get(`line_items[${i}][price_data][product_data][name]`);
r = await get({ cart: box([['Angel Ornament', 'Red', 1], ['Sapphire Cameo Ornament', 'Royal Blue', 1], ['Ballerina Ornament', 'Cream', 1]]), zip: '90210' });
check('box with 3 ornaments = sum of ornaments (25497)', r.status === 303 && amounts()[0] === 25497, JSON.stringify(amounts()));
check('3+ ornaments adds a FREE separate gift box note', /FREE separate gift box/.test(nameOf()) && /contains/.test(nameOf()), nameOf());
r = await get({ cart: box([['Angel Ornament', 'Red', 2]]), zip: '90210' });
check('box with 2 ornaments = 16998 and no free box', amounts()[0] === 16998 && !/FREE/.test(nameOf()), nameOf());
r = await get({ cart: box([['Angel Ornament', 'Red', 1], ['Throne Ornament', 'Cream', 2]]), zip: '90210' });
check('3 ornaments counted by quantity (free box)', /FREE/.test(nameOf()) && amounts()[0] === 8499 + 2 * 7499, JSON.stringify(amounts()));
r = await get({ cart: cart([['Ornament Gift Box', 'Red', 1]]) }); check('box with no contents -> 400', r.status === 400);
r = await get({ cart: box([]) }); check('box with empty list -> 400', r.status === 400);
r = await get({ cart: box([['Ornament Gift Box', 'Red', 1]]) }); check('box inside a box -> 400', r.status === 400);
r = await get({ cart: box([['Fake Ornament', 'Red', 1]]) }); check('unknown ornament in box -> 400', r.status === 400);
r = await get({ cart: box([['Angel Ornament', 'Red', 13]]) }); check('more than 12 ornaments in a box -> 400', r.status === 400);
r = await get({ cart: box([['Angel Ornament', 'Red', 1.5]]) }); check('fractional box quantity -> 400', r.status === 400);
r = await get({ cart: box([['constructor', 'Red', 1]]) }); check('box item named constructor -> 400', r.status === 400);
r = await get({ cart: cart([['Ornament Gift Box', 'Red', 1, [['Angel Ornament', 'Red', 1]], 0.01]]) }); check('a price sent by the browser is ignored for boxes', amounts()[0] === 8499, JSON.stringify(amounts()));
console.log(failed ? '\n' + failed + ' check(s) FAILED' : '\nAll checks passed');
process.exit(failed ? 1 : 0);
